package br.unipar.prova


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var plantAdapter: PlantAdapter
    private lateinit var plantCountTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        plantCountTextView = findViewById(R.id.plant_count)
        val recyclerView: RecyclerView = findViewById(R.id.PlantaView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        plantAdapter = PlantAdapter(RepositorioPlanta.getPlants())
        recyclerView.adapter = plantAdapter

        findViewById<Button>(R.id.add_plant_button).setOnClickListener {
            val intent = Intent(this, AddPlantActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        plantAdapter.updatePlants(RepositorioPlanta.getPlants())
        plantCountTextView.text = "Total de plantas: ${RepositorioPlanta.getPlantCount()}"
    }
}