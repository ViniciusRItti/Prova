package br.unipar.prova

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class AddPlantActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nomePlanta: EditText = findViewById(R.id.nomePlanta)
        val plantDateInput: EditText = findViewById(R.id.dataPlanta)
        val plantCareLevelInput: Spinner = findViewById(R.id.Niveis)

        findViewById<Button>(R.id.Salvar).setOnClickListener {
            val name = nomePlanta.text.toString()
            val date = plantDateInput.text.toString()
            val careLevel = plantCareLevelInput.selectedItem.toString()

            val newPlant = Planta(name, date, careLevel)
            RepositorioPlanta.addPlant(newPlant)

            finish()
        }
    }
}