package br.unipar.prova

data class Planta(
    val nome: String,
    val dataPlantio: String,
    val nivel: String,
    val QtdAgua: Int = 0
)
