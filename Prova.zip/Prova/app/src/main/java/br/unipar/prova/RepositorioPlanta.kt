package br.unipar.prova

object RepositorioPlanta {
    private val plants = mutableListOf<Planta>()

    fun addPlant(plant: Planta) {
        plants.add(plant)
    }

    fun getPlants(): List<Planta> {
        return plants
    }

    fun getPlantCount(): Int {
        return plants.size
    }
}