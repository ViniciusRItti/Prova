package br.unipar.prova

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlantAdapter(private var plants: List<Planta>) : RecyclerView.Adapter<PlantAdapter.PlantViewHolder>() {

    class PlantViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val plantName: TextView = view.findViewById(R.id.nomePlanta)
        val plantDate: TextView = view.findViewById(R.id.dataPlanta)
        val plantCareLevel: TextView = view.findViewById(R.id.Niveis)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlantViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_plant, parent, false)
        return PlantViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlantViewHolder, position: Int) {
        val plant = plants[position]
        holder.plantName.text = plant.nome
        holder.plantDate.text = plant.dataPlantio
        holder.plantCareLevel.text = plant.nivel
    }

    override fun getItemCount(): Int {
        return plants.size
    }

    fun updatePlants(newPlants: List<Planta>) {
        plants = newPlants
        notifyDataSetChanged()
    }
}